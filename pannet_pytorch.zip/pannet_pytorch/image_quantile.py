# -*- coding: utf-8 -*-
"""
Created on Wed Dec 07 13:55:17 2016

@author: R530
"""
import numpy as np

def image_quantile(img,p):
    if len(img.shape) ==2:
        img = np.expand_dims(img,axis=0)
        
    Nk, Nr, Nc = img.shape
    y = np.zeros((Nk, np.size(p)))
    for index in range(Nk):
        y[index,:] = quantile( img[index,:,:], p )
    return y

def quantile(x, p):
    x = np.sort(x.flatten())
    y = []
    for i in range(len(p)):
        th = np.maximum(np.floor(np.size(x)*p[i]), 0).astype('int')
        y.append(x[th])
    return y
    
def image_stretch(img, th):
    img = np.double(img)
    if np.size(th)==2:
        img = (img-th[0][0])/(th[0][1]-th[0][0])
    else:
        Nk,Nr,Nc = img.shape
        for index in range(Nk):
            img[index,:,:] = (img[index,:,:]-th[index,0])/(th[index,1]-th[index,0])
        
    return img