# -*- coding: utf-8 -*-
"""
Created on Wed May 12 22:12:56 2021

@author: sergv
"""

import numpy as np
import scipy.io as sio
import cv2
import torch.optim as optim
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
#%% Settings
method = 'pannet'
pre_trained_path = './models/pre-trained/'
ft_path = './models/ft/'
out_path = './results'
img_path = './'
img_name = 'NY1_WV3_FR.mat'
img_path = img_path+img_name
epochs=0


if not os.path.exists(ft_path):
    os.makedirs(ft_path)

#%% 
def get_edge(data): # get high-frequency
    rs = np.zeros_like(data)
    if len(rs.shape) ==3:
        for i in range(data.shape[2]):
            rs[:,:,i] = data[:,:,i] -cv2.boxFilter(data[:,:,i],-1,(5,5))
    else:
        rs = data - cv2.boxFilter(data,-1,(5,5))
    return rs

def up_ms(ms,ratio):
    
    if len(ms.shape)==3:
        ms = ms[np.newaxis,:,:,:]
    lms =  F.interpolate(torch.from_numpy(ms),scale_factor=4.,mode='bicubic')
    lms = np.asarray(lms.detach().cpu())
    
    return lms


if __name__=='__main__':
    
    data = sio.loadmat(img_path,squeeze_me=True)
    pan = data['I_PAN']
    ms = data['I_MS_LR']
    ms = np.array(ms,dtype = np.float32) 
    pan  = np.array(pan,dtype = np.float32) 
    
    from wald_utilities import wald_protocol_pannet
    ms_lr,pan_lr = wald_protocol_pannet(ms,pan, 4., 'WV3')
    ms_lr = np.array(ms_lr,dtype = np.float32) /2047.
    pan_lr  = np.array(pan_lr,dtype = np.float32) /2047.
    
    lms_lr = up_ms(ms_lr,4.)
    gt = torch.from_numpy(ms.transpose((2,0,1))[np.newaxis,:,:,:])/2047.
#    
    checkpoint = torch.load(pre_trained_path+method+'_pretrained_model')
    net = checkpoint['model']
    net.load_state_dict(checkpoint['model_state'])
    optimizer = optim.Adam(net.parameters(), lr=0.001, betas=(0.9, 0.999), weight_decay=1e-5)
    criterion = nn.L1Loss(reduction='mean').cuda()
    vmin=10000
    ms_lr = torch.from_numpy(ms_lr)
    pan_lr = torch.from_numpy(pan_lr)
    
    "Fine Tuning"
    for epoch in range(epochs):
        optimizer.zero_grad()  # fixed

        rs = net(ms_lr,pan_lr)
        loss = criterion(rs, gt-torch.from_numpy(lms_lr).type(torch.float32))
        
        loss.backward()  # fixed
        optimizer.step()  # fixed
        
        print('Epoch: {}/{} training L1-loss: {:.7f}'.format(epochs, epoch, loss.detach().cpu(), ))  # print loss for each epoch
        if loss.detach().cpu()<vmin:
            torch.save(dict(model=net,model_state=net.state_dict()),ft_path+'/'+method+'_ft_model')
        checkpoint = torch.load(ft_path+'/'+method+'_ft_model')
    
    "Testing"
    
    net = checkpoint['model']
    net.load_state_dict(checkpoint['model_state'])
    
    ms = ms/2047.
    pan = pan/2047.
    lms =  up_ms(ms.transpose((2,0,1)),4.)
        
    ms_hp = get_edge(ms)   # high-frequency parts of MS image
    ms_hp = ms_hp[np.newaxis,:,:,:]

    pan_hp = get_edge(pan) # high-frequency parts of PAN image
    pan_hp = pan_hp[np.newaxis,:,:,np.newaxis]
    
    ms_hp=torch.from_numpy(ms_hp)
    pan_hp=torch.from_numpy(pan_hp)
    ms_hp=ms_hp.permute((0,3,1,2))
    pan_hp=pan_hp.permute((0,3,1,2))
            
    rs = net(ms_hp,pan_hp)
    mrs = np.asarray(rs.detach().cpu())+lms
    mrs = np.clip(mrs,0,1)
    sio.savemat(out_path+'/output_ft_'+str(epochs)+'.mat', {'output':mrs[0,:,:,:]})
