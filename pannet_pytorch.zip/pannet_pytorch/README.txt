per effettuare il test lanciare il file 'testing_fine_tuning.py'
	io ho testato con 'NY1_WV3_FR' e 'NY1_WV3_RR'
	settare FT_epochs = 0 	per evitare il fine_tuning
	settare FT_epochs >0 	per effettuare FT_epochs epoche di fine tuning
	
In wald utilities trovi qualche funzione per il downgrade di pannet, e sicuro qualche funzione refuso di codici vecchi

Il file 'pre_training.py' è il file originale di pre-training (non penso lo useremo)