# -*- coding: utf-8 -*-
"""
Created on Tue May 11 15:58:10 2021

@author: sergv
"""

import scipy.io as sio
import numpy as np
from image_quantile import image_quantile, image_stretch
# img = sio.loadmat('./new_data.mat',squeeze_me=True)
# ms = img['gt']
# lms = img['lms']
# pan = img['pan']
img = sio.loadmat('./NY1_WV3_RR.mat',squeeze_me=True)
pan = img['I_PAN']
ms = img['I_MS_LR']
gt = np.squeeze(img['I_GT'])

img = sio.loadmat('./result/output.mat',squeeze_me=True)
img_py = img['output']*2047
img = sio.loadmat('./result/output_ft_0.mat',squeeze_me=True)
img_ft_0 = img['output']*2047
img = sio.loadmat('./result/output_ft_50.mat',squeeze_me=True)
img_ft_50 = img['output']*2047
#ms_py = img['input']

rgb_indexes = [4,2,1]
thMS = image_quantile(gt[:,:,rgb_indexes].transpose(2,0,1),[0.01,0.99])
thPAN = image_quantile(pan,[0.01,0.99])
#%%
import matplotlib.pyplot as plt
plt.close('all')
plt.figure()
ax1=plt.subplot(131);ax1.imshow(image_stretch(gt[:,:,rgb_indexes].transpose(2,0,1),thMS).transpose((1,2,0)))
# ax2=plt.subplot(222,sharex=ax1,sharey=ax1);ax2.imshow(image_stretch(ms[:,:,rgb_indexes].transpose(2,0,1),thMS).transpose((1,2,0)))
ax3=plt.subplot(132,sharex=ax1,sharey=ax1);ax3.imshow(image_stretch(img_py[rgb_indexes,:,:],thMS).transpose((1,2,0)))
ax4=plt.subplot(133,sharex=ax1,sharey=ax1);ax4.imshow(image_stretch(img_ft_50[rgb_indexes,:,:],thMS).transpose((1,2,0)))

print(np.max(abs(img_ft_0-img_py)))
#print(np.max(abs(ms_tf-ms_py.transpose((1,2,0)))))

#diff = abs(img_tf-img_py)
#diff = diff/np.max(diff)
#for i in range(8):
#    plt.figure()
#    plt.imshow(diff[i,:,:]/2047)
#%%
#x1 = 1
#x2= 64
#y1 = 65
#y2 = 128
#plt.figure()
#plt.subplot(221);plt.imshow(image_stretch(lms[y1:y2,x1:x2,rgb_indexes].transpose(2,0,1),thMS).transpose((1,2,0)))
#plt.subplot(222);plt.imshow(image_stretch(ms[y1:y2,x1:x2,rgb_indexes].transpose(2,0,1),thMS).transpose((1,2,0)))
#plt.subplot(223);plt.imshow(image_stretch(img_py[rgb_indexes,y1:y2,x1:x2],thMS).transpose((1,2,0)))
#plt.subplot(224);plt.imshow(image_stretch(img_tf[rgb_indexes,y1:y2,x1:x2],thMS).transpose((1,2,0)))
