# -*- coding: utf-8 -*-
"""
Created on Wed May 12 09:09:40 2021

@author: sergv
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
    
class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.Conv2d_transpose = nn.ConvTranspose2d(8,8,8,4,padding=(2,2),bias=False)
        self.Conv = nn.Conv2d(9, 32, 3,padding=(1,1))
        self.Conv_1 = nn.Conv2d(32, 32, 3,padding=(1,1))
        self.Conv_2 = nn.Conv2d(32, 32, 3,padding=(1,1))
        self.Conv_3 = nn.Conv2d(32, 32, 3,padding=(1,1))
        self.Conv_4 = nn.Conv2d(32, 32, 3,padding=(1,1))
        self.Conv_5 = nn.Conv2d(32, 32, 3,padding=(1,1))
        self.Conv_6 = nn.Conv2d(32, 32, 3,padding=(1,1))
        self.Conv_7 = nn.Conv2d(32, 32, 3,padding=(1,1))
        self.Conv_8 = nn.Conv2d(32, 32, 3,padding=(1,1))
        self.Conv_9 = nn.Conv2d(32, 8, 3,padding=(1,1))
        
    def forward(self, lms,pan):
        
        x = self.Conv2d_transpose(lms)
        x = torch.cat((x,pan),dim=1)

        x1 = F.relu(self.Conv(x))
        
        x2 = F.relu(self.Conv_1(x1))
        x3 = self.Conv_2(x2)+x1
        
        x4 = F.relu(self.Conv_3(x3))
        x5 = self.Conv_4(x4)+x3
        
        x6 = F.relu(self.Conv_5(x5))
        x7 = self.Conv_6(x6)+x5
        
        x8 = F.relu(self.Conv_7(x7))
        x9 = self.Conv_8(x8)+x7
        
        x10 = self.Conv_9(x9)
        return x10